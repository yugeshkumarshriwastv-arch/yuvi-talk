# YuviTalk Android Source

यह शुरुआती Android प्रोजेक्ट है: Firebase Email/Password authentication और एक shared Firestore chat screen.

## GitHub में डालने का तरीका
1. ZIP को Extract करें.
2. Extract किए गए `YuviTalk_Android_Source` फोल्डर के **अंदर की सभी चीजें** repository के root में upload करें.
3. `google-services.json` को `app/` फोल्डर के अंदर रखें (repository root में नहीं).
4. Firebase Console में Authentication > Sign-in method में Email/Password enable करें.
5. Firestore Database बनाएं और परीक्षण के लिए उपयुक्त सुरक्षित rules सेट करें.
6. GitHub Actions workflow में `gradle --no-daemon assembleDebug` चलाएं.

## जरूरी नोट
- यह पहला working foundation है, पूरा WhatsApp-जैसा ऐप नहीं.
- अभी one shared chat room है; private/group chat, media upload, push notifications, voice/video calling और production security rules अलग से जोड़ने होंगे.
- Firebase Console में Android app का package name `com.yuvitalk.app` होना चाहिए.
