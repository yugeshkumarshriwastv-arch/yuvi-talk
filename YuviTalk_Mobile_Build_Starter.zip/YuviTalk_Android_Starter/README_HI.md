
## केवल मोबाइल से APK build (GitHub Actions)
1. ZIP extract करें और सभी project files GitHub के नए repository में upload करें।
2. `.github/workflows/android.yml` file भी repository में होनी चाहिए।
3. GitHub के Actions tab में `Build Yuvi Talk APK` workflow खोलें और Run workflow दबाएँ।
4. Build सफल होने पर run के Artifacts में `Yuvi-Talk-debug-APK` डाउनलोड करें।
5. ZIP extract करके `app-debug.apk` फोन में install करें। Android unknown-app installation permission माँग सकता है।
यह debug APK है। Public release के लिए signed release build और सुरक्षित signing key चाहिए।
